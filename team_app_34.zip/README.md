# team_app_34

## 로컬 실행

프로젝트 루트에서 FastAPI 서버를 실행합니다.

```powershell
python -m pip install -r server/requirements.txt
python server/main.py
```

별도 터미널에서 Android 에뮬레이터를 대상으로 `flutter run`을 실행합니다.
디버그 앱은 `http://10.0.2.2:8000/diagnosis`로 요청합니다.

실제 Android 기기를 사용할 때는 USB 디버깅을 연결하고 아래 명령을 실행합니다.

```powershell
adb reverse tcp:8000 tcp:8000
flutter run --dart-define=DIAGNOSIS_API_URL=http://127.0.0.1:8000/diagnosis
```

배포 빌드에는 `--dart-define=DIAGNOSIS_API_URL=https://<서버주소>/diagnosis`로
서버 주소를 지정합니다.

## 검사 API

`POST /diagnosis`는 나이, 몸무게, 키, 혈당, 임신 횟수를 받습니다.
서버에서 34세 이하는 `check_age_34_or_under`, 35세 이상은
`check_age_over_34`에 전체 입력을 전달하고, 함수 반환값을 `result`로 응답합니다.
35세 이상 경로는 임신 횟수, BMI 원-핫 값 6개, 혈당 원-핫 값 4개를
차례로 구성합니다. BMI는 몸무게(kg)를 키(m)의 제곱으로 나누어 계산합니다.
경계값은 각 구간의 오른쪽 끝에 포함합니다. 예를 들어 BMI 18.5는 저체중,
혈당 70은 저혈당 범주에 포함됩니다. 나이는 연령 분기에 사용합니다.

`server/artifacts`에 중장년 SVC와 학습된 `StandardScaler` 파일을 보관합니다.
서버는 11개 특성에 `scaler.transform()`을 적용한 뒤 SVC로 예측합니다.
모델 반환값은 `0`이면 정상, `1`이면 당뇨로 표시합니다.
